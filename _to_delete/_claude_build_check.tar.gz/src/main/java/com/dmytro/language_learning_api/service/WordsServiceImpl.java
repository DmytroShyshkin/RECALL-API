package com.dmytro.language_learning_api.service;

import java.net.SocketTimeoutException;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import com.dmytro.language_learning_api.dto.TranslationDTO;
import com.dmytro.language_learning_api.dto.WordsDTO;
import com.dmytro.language_learning_api.dto.requests.EnrichmentRequest;
import com.dmytro.language_learning_api.dto.requests.createRequests.CreateWordRequestDTO;
import com.dmytro.language_learning_api.dto.requests.updateRequests.UpdateWordRequest;
import com.dmytro.language_learning_api.dto.response.EnrichmentResponse;
import com.dmytro.language_learning_api.dto.response.PageResponse;
import com.dmytro.language_learning_api.event.WordDeletedDomainEvent;
import com.dmytro.language_learning_api.exception.EnrichmentException.EnrichmentServiceRateLimitedException;
import com.dmytro.language_learning_api.exception.EnrichmentException.EnrichmentServiceTimeoutException;
import com.dmytro.language_learning_api.exception.EnrichmentException.EnrichmentServiceUnavailableException;
import com.dmytro.language_learning_api.exception.NotFoundException.UserNotFoundException;
import com.dmytro.language_learning_api.exception.NotFoundException.WordNotFoundException;
import com.dmytro.language_learning_api.kafka.producer.word.WordUpsertedProducer;
import com.dmytro.language_learning_api.mapper.TranslationMapper;
import com.dmytro.language_learning_api.mapper.WordUpsertedEventMapper;
import com.dmytro.language_learning_api.mapper.WordsMapper;
import com.dmytro.language_learning_api.model.Translation;
import com.dmytro.language_learning_api.model.Users;
import com.dmytro.language_learning_api.model.Words;
import com.dmytro.language_learning_api.repository.UsersRepository;
import com.dmytro.language_learning_api.repository.WordsRepository;
import com.dmytro.language_learning_api.repository.statistics.WordStatisticsRepository;
import com.dmytro.language_learning_api.security.jwt.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class WordsServiceImpl implements WordsService {

    // Mappers
    private final WordsMapper wordsMapper;
    private final TranslationMapper translationMapper;
    private final WordUpsertedEventMapper wordUpsertedEventMapper;
    // Repository
    private final WordsRepository wordsRepository;
    private final UsersRepository usersRepository;
    private final WordStatisticsRepository wordStatisticsRepository;

    // field name matches the @Bean method name, so Spring resolves it by type + name
    private final RestClient enrichmentServiceRestClient;

    // Kafka
    private final WordUpsertedProducer wordUpsertedProducer;
    private final ApplicationEventPublisher eventPublisher;

    // Security helper
    private final JwtUtil jwtUtil;

    @Override
    public WordsDTO createWord(CreateWordRequestDTO request) {
        String email = SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();

        Users user = usersRepository.findByEmail(email)
                .orElseThrow();

        Words word = new Words();
        word.setOriginalWord(request.originalWord());
        word.setSourceLanguage(request.sourceLanguage());
        word.setOwner(user);

        Words savedWord = wordsRepository.save(word);
        wordUpsertedProducer.sendWordUpsertedEvent(wordUpsertedEventMapper.toEvent(savedWord));

        return wordsMapper.toDto(savedWord);
    }

    @Transactional(readOnly = true)
    @Override
    public WordsDTO getWordById(UUID wordId) {
        Words word = getWordOrThrow(wordId);
        return toFullDto(word);
    }

    @Override
    public WordsDTO updateWord(UUID wordId, UpdateWordRequest updateWordRequest) {
        Words word = getWordOrThrow(wordId);

        if (updateWordRequest.sourceLanguage() != null && !updateWordRequest.sourceLanguage().isBlank()
                && !updateWordRequest.sourceLanguage().equals(word.getSourceLanguage())) {
            word.setSourceLanguage(updateWordRequest.sourceLanguage());
        }

        if (updateWordRequest.originalWord() != null && !updateWordRequest.originalWord().isBlank()
                && !updateWordRequest.originalWord().equals(word.getOriginalWord())) {
            word.setOriginalWord(updateWordRequest.originalWord());
        }

        Words savedWord = wordsRepository.save(word);
        wordUpsertedProducer.sendWordUpsertedEvent(wordUpsertedEventMapper.toEvent(savedWord));

        return wordsMapper.toDto(savedWord);
    }

    @Transactional
    @Override
    public void enrichWord(UUID wordId, String targetLanguage) {
        Words word = getWordOrThrow(wordId);

        Users currentUser = jwtUtil.getCurrentUser();
        if (!word.getOwner().equals(currentUser)) {
            throw new AccessDeniedException("You don't own this word");
        }

        Translation translation = word.getTranslations().stream()
                .filter(t -> t.getTargetLanguage().equals(targetLanguage))
                .findFirst()
                .orElseGet(() -> {
                    Translation newTranslation = new Translation();
                    newTranslation.setTargetLanguage(targetLanguage);
                    newTranslation.setWord(word);
                    newTranslation.setSource("ai");
                    word.getTranslations().add(newTranslation);
                    return newTranslation;
                });

        EnrichmentRequest enrichmentRequest = new EnrichmentRequest(
                word.getOriginalWord(),
                word.getSourceLanguage(),
                targetLanguage
        );

        EnrichmentResponse response;
        try {
            response = enrichmentServiceRestClient
                .post()
                .uri("/enrich")
                .body(enrichmentRequest)
                .retrieve()
                .onStatus(status -> status.value() == 429, (request, httpResponse) -> {
                    throw new EnrichmentServiceRateLimitedException();
                })
                .onStatus(status -> status.value() == 503, (request, httpResponse) -> {
                    throw new EnrichmentServiceUnavailableException();
                })
                .body(EnrichmentResponse.class);
        } catch (ResourceAccessException ex) {
            if (ex.getCause() instanceof SocketTimeoutException) {
                throw new EnrichmentServiceTimeoutException();
            }
            throw new EnrichmentServiceUnavailableException();
        }

        translation.setTranslatedWord(response.translation());
        translation.setDescription(response.description());
        saveAndPublishUpdate(word);
    }

    @Override
    public PageResponse<WordsDTO> getAllWordsByOwnerEmail(String ownerEmail, int pageNo, int pageSize) {
        Users user = usersRepository.findByEmail(ownerEmail)
                .orElseThrow(
                        ()-> new UserNotFoundException("User by email '" + ownerEmail + "' not found")
                );

        Pageable pageable = PageRequest.of(pageNo, pageSize);
        Page<Words> wordsPage = wordsRepository.findByOwnerId(user.getId(), pageable);
        List<Words> words = wordsPage.getContent();
        List<WordsDTO> wordsList = words.stream()
                .map(this::toFullDto)
                .toList();

        PageResponse<WordsDTO> wordRespons = new PageResponse<>();
        wordRespons.setContent(wordsList);
        wordRespons.setPageNo(wordsPage.getNumber());
        wordRespons.setPageSize(wordsPage.getSize());
        wordRespons.setTotalPages(wordsPage.getTotalPages());
        wordRespons.setTotalElements(wordsPage.getTotalElements());
        wordRespons.setLast(wordsPage.isLast());

        return wordRespons;
    }

    @Override
    public WordsDTO addTranslationToWord(UUID wordId, TranslationDTO translationDto) {
        Words word = getWordOrThrow(wordId);

        Translation translation = translationMapper.fromDto(translationDto);
        translation.setWord(word);

        word.getTranslations().add(translation);
        Words savedWord = wordsRepository.save(word);
        wordUpsertedProducer.sendWordUpsertedEvent(wordUpsertedEventMapper.toEvent(savedWord));

        return wordsMapper.toDto(savedWord);
    }

    @Transactional
    @Override
    public void addSynonym(UUID wordId, UUID synonymId) {
        if (wordId.equals(synonymId)) {
            throw new IllegalArgumentException("A word cannot be a synonym of itself");
        }

        Words word = wordsRepository.findById(wordId)
                .orElseThrow(() -> new WordNotFoundException("Word not found"));

        Words synonym = wordsRepository.findById(synonymId)
                .orElseThrow(() -> new WordNotFoundException("Synonym word not found"));

        Users currentUser = jwtUtil.getCurrentUser();

        if (!word.getOwner().equals(currentUser) ||
                !synonym.getOwner().equals(currentUser)) {
            throw new AccessDeniedException("You don't own these words");
        }

        linkSynonyms(word, synonym);

        wordsRepository.save(word);
        wordsRepository.save(synonym);
    }

    @Transactional
    @Override
    public void removeSynonym(UUID wordId, UUID synonymId) {
        if (wordId.equals(synonymId)) {
            throw new IllegalArgumentException("A word cannot be a synonym of itself");
        }

        Words word = wordsRepository.findById(wordId)
                .orElseThrow(() -> new WordNotFoundException("Word not found"));

        Words synonym = wordsRepository.findById(synonymId)
                .orElseThrow(() -> new WordNotFoundException("Synonym word not found"));

        Users currentUser = jwtUtil.getCurrentUser();

        if (!word.getOwner().equals(currentUser) ||
                !synonym.getOwner().equals(currentUser)) {
            throw new AccessDeniedException("You don't own these words");
        }

        unlinkSynonyms(word, synonym);

        wordsRepository.save(word);
        wordsRepository.save(synonym);
    }

    @Override
    @Transactional
    public void deleteWord(UUID wordId) {
        Words word = getWordOrThrow(wordId);
        eventPublisher.publishEvent(new WordDeletedDomainEvent(wordId, word.getOwner().getEmail()));
        wordStatisticsRepository.deleteByWordId(wordId);
        wordsRepository.delete(word);
    }

    // Clases auxiliares
    private Words getWordOrThrow(UUID wordId) {
        return wordsRepository
                .findById(wordId)
                .orElseThrow(() -> new WordNotFoundException(
                        "Word with id " + wordId + " not found"
                ));
    }

    private WordsDTO toFullDto(Words word) {
        WordsDTO dto = wordsMapper.toDto(word);

        Set<UUID> synonymIds = word.getSynonyms() == null
                ? Collections.emptySet()
                : word.getSynonyms().stream()
                .map(arg0 -> arg0.getId())
                .collect(Collectors.toSet());

        List<TranslationDTO> translations = word.getTranslations() == null
                ? Collections.emptyList()
                : word.getTranslations().stream()
                .map(translationMapper::toDto)
                .toList();

        return new WordsDTO(
                dto.id(),
                dto.sourceLanguage(),
                dto.originalWord(),
                synonymIds,
                translations
        );
    }


    private void linkSynonyms(Words a, Words b) {
        if (a.getId().equals(b.getId())) return;

        a.getSynonyms().add(b);
        b.getSynonyms().add(a);
    }

    private void unlinkSynonyms(Words a, Words b) {
        if (a.getId().equals(b.getId())) return;

        a.getSynonyms().remove(b);
        b.getSynonyms().remove(a);
    }

    private void saveAndPublishUpdate(Words word) {
        wordsRepository.save(word);
        wordUpsertedProducer.sendWordUpsertedEvent(wordUpsertedEventMapper.toEvent(word));
    }
}
